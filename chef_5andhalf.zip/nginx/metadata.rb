name             'nginx'
maintainer       'Admin 5.5'
maintainer_email 'admin@5andhalf.com'
license          'All rights reserved'
description      'Install/Configure nginx'
# long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'

depends "aptget"

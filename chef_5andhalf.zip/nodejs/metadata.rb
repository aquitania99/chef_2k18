name             'nodejs'
maintainer       'Admin 5.5'
maintainer_email 'admin@5andhalf.com'
license          'All rights reserved'
description      'Installs/Configures NodeJs'
long_description 'Installs/Configures NodeJs'
version          '0.1.0'

depends "aptget"
